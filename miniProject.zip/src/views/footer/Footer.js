import '../../styles/Footer.scss'

const Footer = () => {
    return (
        <>
            <div className="footer">
                <p>Mini Project Group 2 ®️ By 2023</p>
            </div>
        </>
    )
}
export default Footer;